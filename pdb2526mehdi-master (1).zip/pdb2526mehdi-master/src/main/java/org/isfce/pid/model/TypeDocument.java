package org.isfce.pid.model;

public enum TypeDocument {
	
	BULLETIN, PROGRAMME, MOTIVATION, AUTRE
	
}
